# Render-ready project

Upload all files from this folder directly into the ROOT of your GitHub repo.
Do NOT put them inside another folder.

Build Command:
    pip install -r requirements.txt

Start Command:
    python bot.py
