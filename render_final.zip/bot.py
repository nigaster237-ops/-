import os
import logging
import random
import time
import asyncio
import sys
import json
import aiohttp
from aiogram import Bot, Dispatcher, types, F, Router
from aiogram.types import (
    InlineKeyboardButton, 
    InlineKeyboardMarkup, 
    ReplyKeyboardMarkup, 
    KeyboardButton, 
    Message, 
    CallbackQuery
)
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from telethon import TelegramClient, events
from telethon.errors import (
    SessionPasswordNeededError, 
    SessionRevokedError,
    AuthKeyDuplicatedError,
    AuthKeyUnregisteredError,
    RPCError
)
from telethon.tl.types import User, Channel, Chat
from aiohttp_socks import ProxyConnector, ProxyType

# ===================== КОНФИГУРАЦИЯ =====================
# Настройки прокси
USE_PROXY = True
PROXY_TYPE = "socks5"
PROXY_HOST = "194.87.7.176"
PROXY_PORT = 63479
PROXY_USER = "GXjt8nK3"
PROXY_PASS = "ghhPdd4C"

# Настройки OpenAI - ЗАМЕНИТЕ НА ВАШ РЕАЛЬНЫЙ API КЛЮЧ
OPENAI_API_KEY = "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"

# ТОЛЬКО ОДНА РАБОЧАЯ МОДЕЛЬ
GPT_MODEL = "gpt-4o-mini"

# Глобальные настройки
ADMIN_ID = 6310416559
HISTORY_FILE = "chat_history.json"
CONFIG_FILE = "config.json"
SESSION_DIR = "sessions"

# НАСТРОЙКИ ЗАДЕРЖЕК И ОГРАНИЧЕНИЙ
MAX_CONCURRENT_REQUESTS = 1
REQUEST_TIMEOUT = 30
MIN_DELAY_BETWEEN_REQUESTS = 7.5
MAX_DELAY_BETWEEN_REQUESTS = 9.0
MIN_DELAY_BETWEEN_RESPONSES = 5  # Минимальная задержка между ответами пользователю (секунды)
MAX_DELAY_BETWEEN_RESPONSES = 6  # Максимальная задержка между ответами пользователю (секунды)
MAX_MESSAGES_PER_MINUTE = 25

# ОГРАНИЧЕНИЯ ДЛЯ ПРЕДОТВРАЩЕНИЯ СПАМА
MAX_RESPONSE_LENGTH = 500  # УВЕЛИЧЕНО с 50 до 500 символов
MAX_MESSAGE_PARTS = 1     # ТОЛЬКО 1 сообщение на ответ (не разбивать на части!)

# НОВЫЕ НАСТРОЙКИ: ФИЛЬТРАЦИЯ КОРОТКИХ СООБЩЕНИЙ
SHORT_MESSAGE_THRESHOLD = 5  # Сообщения короче этого не обрабатываются (символы)
SHORT_RESPONSE_PATTERNS = [
    # Односложные ответы
    "ок", "окей", "ага", "угу", "хм", "ну", "да", "нет", "ясно", "понятно", "ясн", "пон",
    "хорошо", "ладно", "хор", "ладн", "принято", "прин",
    
    # Краткие согласия
    "хорошо понял", "ясно понял", "понял принял", "ок понял", "ясно спасибо",
    "понял спс", "ясн спс", "спс понял", "ясно спс",
    
    # Короткие подтверждения
    "все понял", "все ясно", "все ок", "все хорошо", "все хор",
    "ясно все", "понял все", "ок все", "все ладно",
    
    # Благодарности
    "спасибо", "спс", "благодарю", "мерси", "пасиб", "пасибо",
    "спасибо большое", "спс большое", "большое спасибо",
    
    # Прощания
    "пока", "бай", "всего доброго", "до свидания", "до связи",
    "удачи", "всего хорошего", "будь", "чао", "покеда",
    
    # Междометия
    "ого", "вау", "огонь", "круто", "супер", "отлично", "норм",
    "здорово", "класс", "шикарно", "прекрасно", "замечательно",
    
    # Вопросы (только если очень короткие)
    "кто", "что", "где", "когда", "почему", "зачем", "как", "какой",
    "чо", "чё", "шо", "а", "и", "но", "или"
]
# ========================================================

# Создаем директории
os.makedirs(SESSION_DIR, exist_ok=True)

# Настройка логгера
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(stream=sys.stdout),
        logging.FileHandler("multi_account_bot.log", encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

# Семафор для ограничения одновременных запросов к OpenAI
openai_semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)

# Трекер запросов для rate limiting
request_tracker = {
    'count': 0,
    'window_start': time.time(),
    'last_request_time': 0
}

# Трекер времени последнего ответа для каждого чата
last_response_time = {}

# Состояния для FSM
class AccountStates(StatesGroup):
    waiting_session_name = State()
    waiting_phone = State()
    waiting_api_id = State()
    waiting_api_hash = State()
    waiting_code = State()
    waiting_password = State()
    waiting_account_prompt = State()
    waiting_blocked_user = State()
    waiting_remove_blocked = State()

class PromptStates(StatesGroup):
    waiting_global_prompt = State()

class AdminStates(StatesGroup):
    waiting_admin_id = State()
    waiting_remove_admin = State()

# Глобальный конфиг
global_config = {
    "ai_prompt": (
        "Ты — Ксения 29 лет из Донецка Увлекаешься НФТ и цифровым искусством "
        "Общайся просто без формальностей как с подругой "
        "Используй разговорные фразы Отвечай КОРОТКО максимум 2-3 коротких предложения "
        "Добавляй немного юмора но без флирта Никогда не упоминай что ты ИИ или бот "
        "ПИШИ КАК ЧЕЛОВЕК В ОБЫЧНОМ ЧАТЕ: "
        "НИКОГДА НЕ СТАВЬ ТОЧКИ В КОНЦЕ ПРЕДЛОЖЕНИЙ "
        "НИКОГДА НЕ СТАВЬ ВОСКЛИЦАТЕЛЬНЫЕ ЗНАКИ "
        "ИСПОЛЬЗУЙ МЕНЬШЕ ЗАПЯТЫХ пиши как в смс "
        "МОЖЕШЬ СТАВИТЬ ВОПРОСИТЕЛЬНЫЕ ЗНАКИ КОГДА ЗАДАЕШЬ ВОПРОС "
        "НЕ ИСПОЛЬЗУЙ СМАЙЛИКИ И ЭМОДЗИ "
        "ПИШИ С МАЛЕНЬКОЙ БУКВЫ КАК В ОБЫЧНОМ ЧАТЕ "
        "ИСПОЛЬЗУЙ СОКРАЩЕНИЯ: СПС ВМЕСТО СПАСИБО ЧО ВМЕСТО ЧТО ЩА ВМЕСТО СЕЙЧАС "
        "БУДЬ ЕСТЕСТВЕННОЙ КАК РЕАЛЬНЫЙ ЧЕЛОВЕК В ТЕЛЕГРАМЕ "
        "НЕ НАЧИНАЙ ОТВЕТ СО СЛОВ ЧО ЧТО ЩА СПС ЭТО НЕЕСТЕСТВЕННО "
        "ИЗБЕГАЙ ЧРЕЗМЕРНОГО ИСПОЛЬЗОВАНИЯ ЗАПЯТЫХ ПИШИ БОЛЕЕ ПЛОТНО "
        "ЕСЛИ СООБЩЕНИЕ КОРОТКОЕ ИЛИ ПОДТВЕРЖДАЮЩЕЕ (ОК ПОНЯТНО СПС) - НЕ ОТВЕЧАЙ НА НЕГО"
    ),
    "accounts": {},
    "admins": [ADMIN_ID]  # Список администраторов (первый - главный админ)
}

# Словарь для хранения истории диалогов
conversation_history = {}

# Словарь для статистики
message_stats = {}
pending_verification = {}
active_clients = {}

# Загрузка истории диалогов
def load_history():
    global conversation_history
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                conversation_history = json.load(f)
                logger.info("Загружена история из %s диалогов", len(conversation_history))
    except Exception as e:
        logger.error("Ошибка загрузки истории: %s", e)
        conversation_history = {}

# Сохранение истории диалогов
def save_history():
    try:
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(conversation_history, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error("Ошибка сохранения истории: %s", e)

# Загрузка конфигурации
def load_config():
    global global_config
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                saved_config = json.load(f)
                
                global_config["ai_prompt"] = saved_config.get("ai_prompt", global_config["ai_prompt"])
                global_config["accounts"] = saved_config.get("accounts", {})
                global_config["admins"] = saved_config.get("admins", [ADMIN_ID])
                
                logger.info("Конфигурация загружена")
    except Exception as e:
        logger.error("Ошибка загрузки конфига: %s", e)
        save_config()

# Сохранение конфигурации
def save_config():
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(global_config, f, indent=2, ensure_ascii=False)
        logger.info("Конфигурация сохранена")
    except Exception as e:
        logger.error("Ошибка сохранения конфига: %s", e)

# Инициализация
load_config()
load_history()

# ===================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ =====================
async def rate_limit_delay():
    """Задержка для соблюдения rate limiting OpenAI"""
    global request_tracker
    
    current_time = time.time()
    elapsed_since_window_start = current_time - request_tracker['window_start']
    
    if elapsed_since_window_start > 60:
        request_tracker['count'] = 0
        request_tracker['window_start'] = current_time
        elapsed_since_window_start = 0
    
    if request_tracker['count'] >= MAX_MESSAGES_PER_MINUTE:
        wait_time = 60 - elapsed_since_window_start + 2
        logger.warning("Достигнут лимит запросов Жду %.1f секунд", wait_time)
        
        try:
            await config_bot.send_message(
                ADMIN_ID,
                f"Достигнут лимит запросов OpenAI\n"
                f"Жду {int(wait_time)} секунд"
            )
        except:
            pass
        
        await asyncio.sleep(wait_time)
        request_tracker['count'] = 0
        request_tracker['window_start'] = time.time()
    
    time_since_last_request = current_time - request_tracker['last_request_time']
    if time_since_last_request < MIN_DELAY_BETWEEN_REQUESTS:
        wait_time = MIN_DELAY_BETWEEN_REQUESTS - time_since_last_request
        await asyncio.sleep(wait_time)
    
    request_tracker['count'] += 1
    request_tracker['last_request_time'] = time.time()

def get_proxy_connector():
    """Создает коннектор для прокси"""
    if not USE_PROXY:
        return None
        
    proxy_type = {
        "socks5": ProxyType.SOCKS5,
        "http": ProxyType.HTTP
    }.get(PROXY_TYPE.lower(), ProxyType.SOCKS5)
    
    return ProxyConnector(
        proxy_type=proxy_type,
        host=PROXY_HOST,
        port=PROXY_PORT,
        username=PROXY_USER,
        password=PROXY_PASS,
        rdns=True
    )

def get_proxy_settings():
    """Возвращает настройки прокси для Telethon"""
    if not USE_PROXY:
        return None
        
    return (
        ProxyType.SOCKS5 if PROXY_TYPE == "socks5" else ProxyType.HTTP,
        PROXY_HOST,
        PROXY_PORT,
        True,
        PROXY_USER,
        PROXY_PASS
    )

def calculate_typing_time(text_length):
    """Задержка перед отправкой сообщения (печатает)"""
    # Чем короче текст, тем быстрее печатает
    if text_length < 50:
        return random.uniform(1.5, 2.5)
    elif text_length < 100:
        return random.uniform(2.0, 3.0)
    else:
        return random.uniform(2.5, 4.0)

def get_response_delay():
    """Возвращает задержку между ответами пользователю (30-60 секунд)"""
    return random.uniform(MIN_DELAY_BETWEEN_RESPONSES, MAX_DELAY_BETWEEN_RESPONSES)

def truncate_response(text, max_length=MAX_RESPONSE_LENGTH):
    """Обрезает текст до максимальной длины"""
    if not text:
        return ""
    
    text = text.strip()
    
    if len(text) <= max_length:
        return text
    
    # Ищем последнее подходящее место для обрезки
    truncated = text[:max_length]
    
    # Ищем последнюю запятую или вопрос
    last_comma = truncated.rfind(',')
    last_question = truncated.rfind('?')
    
    cut_position = max(last_comma, last_question)
    
    if cut_position > max_length * 0.7:  # Если есть подходящее место
        truncated = truncated[:cut_position + 1].strip()
    else:
        # Ищем последний пробел
        last_space = truncated.rfind(' ')
        if last_space > max_length * 0.8:
            truncated = truncated[:last_space].strip()
    
    return truncated

def is_short_message(text):
    """Проверяет, является ли сообщение коротким и тривиальным"""
    if not text:
        return True
    
    text_lower = text.lower().strip()
    
    # Проверка по длине
    if len(text_lower) < SHORT_MESSAGE_THRESHOLD:
        # Проверка на совпадение с паттернами коротких сообщений
        for pattern in SHORT_RESPONSE_PATTERNS:
            if pattern in text_lower:
                return True
        
        # Проверка на одно слово
        words = text_lower.split()
        if len(words) <= 2:
            return True
        
        # Проверка на только подтверждающие слова
        confirming_words = ['ок', 'окей', 'ага', 'угу', 'ясно', 'понятно', 'спс', 'спасибо', 'хорошо']
        if all(word in confirming_words for word in words):
            return True
    
    return False

def clean_human_text(text):
    """Очищает текст делает его похожим на человеческое сообщение в чате"""
    if not text or text.strip() == "":
        return random.choice(["ага", "понятно", "ясно", "окей", "хм", "ну да"])
    
    text = text.strip()
    
    # Убираем все точки, восклицательные знаки и двоеточия в конце
    while text and text[-1] in '.!;:':
        text = text[:-1]
    
    # Убираем многоточия
    while text.endswith('...'):
        text = text[:-3]
    
    # Убираем лишние пробелы
    text = ' '.join(text.split())
    
    # Всегда делаем первую букву строчной (как в чате)
    if text and len(text) > 0:
        text = text[0].lower() + text[1:] if text[0].isupper() else text
    
    # Заменяем формальные слова на разговорные (ИСКЛЮЧИЛ "привет" ИЗ ЗАМЕН)
    replacements = {
        'спасибо': 'спс',
        'что': 'чо',
        'чего': 'чё',
        'пока': 'бай',
        'сейчас': 'ща',
        'хорошо': 'ок',
        'отлично': 'норм',
        'понятно': 'ясн',
        'конечно': 'конечн'
    }
    
    for formal, informal in replacements.items():
        if formal in text.lower():
            # Сохраняем регистр
            if formal in text:
                text = text.replace(formal, informal)
            elif formal.capitalize() in text:
                text = text.replace(formal.capitalize(), informal)
    
    # УБИРАЕМ ЧРЕЗМЕРНОЕ КОЛИЧЕСТВО ЗАПЯТЫХ
    # Удаляем запятые в начале
    while text.startswith(','):
        text = text[1:].strip()
    
    # Удаляем повторяющиеся запятые
    while ',,' in text:
        text = text.replace(',,', ',')
    
    # Удаляем запятые перед пробелами в конце коротких фраз
    words = text.split()
    if len(words) <= 4:  # Для коротких фраз
        text = text.replace(',', '')
    
    # Убираем запятые в самом конце
    if text.endswith(','):
        text = text[:-1]
    
    # Убираем слово "чо" в начале ответа - оно не естественно
    text_lower = text.lower()
    if text_lower.startswith('чо ') or text_lower.startswith('чё ') or text_lower.startswith('что '):
        text = text[text.find(' ') + 1:].strip()
    elif text_lower == 'чо' or text_lower == 'чё' or text_lower == 'что':
        # Заменяем одиночное "чо" на более естественное
        text = random.choice(["хм", "интересно", "ну да", "ясно"])
    
    # Убираем слово "ща" в начале
    if text_lower.startswith('ща '):
        text = text[3:].strip()
    
    # Убираем слово "спс" в начале
    if text_lower.startswith('спс '):
        text = text[4:].strip()
    
    return text

def check_response_cooldown(session_name, chat_id):
    """Проверяет, можно ли отправлять ответ (задержка 30-60 секунд)"""
    key = f"{session_name}_{chat_id}"
    current_time = time.time()
    
    if key in last_response_time:
        time_since_last_response = current_time - last_response_time[key]
        
        if time_since_last_response < MIN_DELAY_BETWEEN_RESPONSES:
            remaining_time = MIN_DELAY_BETWEEN_RESPONSES - time_since_last_response
            logger.info("[%s] Задержка для чата %s: %.1f сек до следующего ответа", 
                       session_name, chat_id, remaining_time)
            return False, remaining_time
    
    return True, 0

def update_response_time(session_name, chat_id):
    """Обновляет время последнего ответа"""
    key = f"{session_name}_{chat_id}"
    last_response_time[key] = time.time()

def check_admin_access(user_id):
    """Проверяет, является ли пользователь администратором"""
    return user_id in global_config["admins"]

def check_main_admin(user_id):
    """Проверяет, является ли пользователь главным администратором"""
    return user_id == ADMIN_ID

def get_accounts_keyboard():
    """Клавиатура для управления аккаунтами"""
    builder = InlineKeyboardBuilder()
    
    if not global_config["accounts"]:
        builder.button(text="Добавить аккаунт", callback_data="add_account")
        builder.button(text="В главное меню", callback_data="main_menu")
        builder.adjust(1)
    else:
        for session_name in global_config["accounts"].keys():
            status = "🟢" if session_name in active_clients else "🔴"
            enabled = "✅" if global_config["accounts"][session_name].get("enabled", True) else "⭕️"
            custom_prompt = "📝" if global_config["accounts"][session_name].get("ai_prompt") else "🌐"
            blocked_count = len(global_config["accounts"][session_name].get("blocked_users", []))
            blocked_icon = "🚫" if blocked_count > 0 else ""
            builder.button(
                text=f"{status}{enabled}{custom_prompt}{blocked_icon} {session_name[:10]}", 
                callback_data=f"account:{session_name}"
            )
        
        builder.button(text="Добавить аккаунт", callback_data="add_account")
        builder.button(text="Обновить", callback_data="refresh_accounts")
        builder.button(text="В главное меню", callback_data="main_menu")
        builder.adjust(2, 1)
    
    return builder.as_markup()

def get_cancel_keyboard():
    """Клавиатура для отмены"""
    builder = InlineKeyboardBuilder()
    builder.button(text="Отмена", callback_data="cancel_operation")
    return builder.as_markup()

def get_account_management_keyboard(session_name):
    """Клавиатура для управления конкретным аккаунтом"""
    builder = InlineKeyboardBuilder()
    
    builder.button(text="Переподключить", callback_data=f"reconnect:{session_name}")
    builder.button(text="Промпт", callback_data=f"edit_prompt:{session_name}")
    builder.button(text="Черный список", callback_data=f"blocked_list:{session_name}")
    
    enabled_text = "Выключить" if global_config["accounts"][session_name].get("enabled", True) else "Включить"
    builder.button(text=enabled_text, callback_data=f"toggle:{session_name}")
    builder.button(text="Удалить", callback_data=f"delete:{session_name}")
    builder.button(text="Назад", callback_data="back_to_accounts")
    
    builder.adjust(2, 2, 1)
    return builder.as_markup()

def get_blocked_management_keyboard(session_name):
    """Клавиатура для управления черным списком"""
    builder = InlineKeyboardBuilder()
    
    blocked_users = global_config["accounts"][session_name].get("blocked_users", [])
    
    if blocked_users:
        builder.button(text="Показать список", callback_data=f"show_blocked:{session_name}")
        builder.button(text="Добавить пользователя", callback_data=f"add_blocked:{session_name}")
        builder.button(text="Удалить пользователя", callback_data=f"remove_blocked:{session_name}")
        builder.button(text="Очистить список", callback_data=f"clear_blocked:{session_name}")
    else:
        builder.button(text="Добавить пользователя", callback_data=f"add_blocked:{session_name}")
    
    builder.button(text="Назад к аккаунту", callback_data=f"account:{session_name}")
    builder.adjust(2, 1, 1)
    return builder.as_markup()

def get_prompt_management_keyboard(session_name):
    """Клавиатура для управления промптами аккаунта"""
    builder = InlineKeyboardBuilder()
    
    has_custom_prompt = "ai_prompt" in global_config["accounts"][session_name]
    if has_custom_prompt:
        builder.button(text="Просмотреть промпт", callback_data=f"view_prompt:{session_name}")
        builder.button(text="Изменить промпт", callback_data=f"change_prompt:{session_name}")
        builder.button(text="Удалить промпт", callback_data=f"delete_prompt:{session_name}")
    else:
        builder.button(text="Добавить промпт", callback_data=f"add_prompt:{session_name}")
    
    builder.button(text="Назад к аккаунту", callback_data=f"account:{session_name}")
    builder.adjust(2, 1, 1)
    return builder.as_markup()

def get_settings_keyboard():
    """Клавиатура настроек"""
    builder = InlineKeyboardBuilder()
    builder.button(text="Глобальный промпт", callback_data="global_prompt")
    builder.button(text="Статистика", callback_data="show_stats")
    builder.button(text="Управление аккаунтами", callback_data="manage_accounts")
    builder.button(text="Управление админами", callback_data="manage_admins")
    builder.button(text="В главное меню", callback_data="main_menu")
    builder.adjust(2, 2, 1)
    return builder.as_markup()

def get_admin_management_keyboard():
    """Клавиатура для управления администраторами"""
    builder = InlineKeyboardBuilder()
    
    builder.button(text="Показать список админов", callback_data="show_admins")
    builder.button(text="Добавить админа", callback_data="add_admin")
    builder.button(text="Удалить админа", callback_data="remove_admin")
    builder.button(text="Назад в настройки", callback_data="system_settings")
    builder.adjust(2, 1, 1)
    return builder.as_markup()

def create_main_keyboard():
    """Основная клавиатура"""
    builder = ReplyKeyboardBuilder()
    
    builder.button(text="Статистика")
    builder.button(text="Аккаунты")
    builder.button(text="Настройки")
    builder.button(text="Промпт")
    builder.button(text="Перезапуск")
    builder.button(text="Очистить историю")
    builder.button(text="Помощь")
    
    if check_main_admin(builder._message.from_user.id if hasattr(builder, '_message') else ADMIN_ID):
        builder.button(text="Админка")
    
    builder.adjust(2, 2, 2, 1)
    return builder.as_markup(resize_keyboard=True)

# ===================== ИНИЦИАЛИЗАЦИЯ BOT =====================
config_bot = Bot(token="7980779198:AAGRX0fq-hXwrNMBjOwb8PuDkdgV7sZ4vf0")
storage = MemoryStorage()
dp = Dispatcher(storage=storage)
router = Router()
dp.include_router(router)

# ===================== МИДЛВАРЬ ДЛЯ ПРОВЕРКИ АДМИНА =====================
@router.message.middleware
async def admin_check_middleware(handler, event: types.Message, data: dict):
    # Пропускаем команду /start для всех
    if event.text and event.text.startswith('/start'):
        return await handler(event, data)
    
    # Пропускаем команду /help для всех
    if event.text and event.text.startswith('/help'):
        return await handler(event, data)
    
    # Проверяем, является ли пользователь администратором
    user_id = event.from_user.id
    
    if not check_admin_access(user_id):
        await event.answer("Доступ запрещен У вас нет прав администратора")
        return
    
    return await handler(event, data)

@router.callback_query.middleware
async def admin_check_callback_middleware(handler, event: types.CallbackQuery, data: dict):
    # Пропускаем некоторые общие callback
    if event.data in ["main_menu", "cancel_operation", "cancel_clear"]:
        return await handler(event, data)
    
    # Проверяем, является ли пользователь администратором
    user_id = event.from_user.id
    
    if not check_admin_access(user_id):
        await event.answer("Доступ запрещен", show_alert=True)
        return
    
    return await handler(event, data)

# ===================== ОБРАБОТЧИКИ КОМАНД =====================
@router.message(CommandStart())
async def cmd_start(message: Message):
    user_id = message.from_user.id
    is_admin = check_admin_access(user_id)
    is_main_admin = check_main_admin(user_id)
    
    admin_status = "Главный администратор" if is_main_admin else "Администратор" if is_admin else "Пользователь"
    
    welcome_text = (
        f"Привет это AI Assistant Bot\n\n"
        f"Твой статус: {admin_status}\n"
        f"Активных аккаунтов: {len(active_clients)}/{len(global_config['accounts'])}\n"
        f"Модель ИИ: GPT-4o-mini\n"
        f"Лимит запросов: {MAX_MESSAGES_PER_MINUTE}/мин\n"
        f"Макс длина ответа: {MAX_RESPONSE_LENGTH} символов\n"
        f"Задержка между ответами: {MIN_DELAY_BETWEEN_RESPONSES}-{MAX_DELAY_BETWEEN_RESPONSES} сек\n"
        f"Сообщений на ответ: 1 (не разбиваются)\n"
        f"Игнор коротких сообщений: ДА (менее {SHORT_MESSAGE_THRESHOLD} символов)\n\n"
    )
    
    if is_admin:
        welcome_text += (
            "Основные команды:\n"
            "Статистика — показать статистику\n"
            "Аккаунты — управление аккаунтами\n"
            "Настройки — настройки системы\n"
            "Промпт — изменить глобальный промпт\n"
            "Перезапуск — перезапуск всех аккаунтов\n"
            "Очистить историю — очистить все диалоги\n"
            "Помощь — справка\n"
        )
        
        if is_main_admin:
            welcome_text += "Админка — управление администраторами\n"
    else:
        welcome_text += "У тебя нет доступа к управлению системой"
    
    await message.answer(welcome_text, reply_markup=create_main_keyboard())

@router.message(Command("help"))
async def cmd_help(message: Message):
    if not check_admin_access(message.from_user.id):
        await message.answer("Доступ запрещен")
        return
    
    help_text = (
        "Руководство по использованию\n\n"
        "Настройки ответов:\n"
        f"Максимальная длина ответа: {MAX_RESPONSE_LENGTH} символов\n"
        f"Задержка между ответами: {MIN_DELAY_BETWEEN_RESPONSES}-{MAX_DELAY_BETWEEN_RESPONSES} секунд\n"
        f"Игнорирование коротких сообщений: ДА (менее {SHORT_MESSAGE_THRESHOLD} символов)\n"
        "Одно сообщение на ответ (не разбивается на части)\n"
        "Автоматическое обрезание длинных ответов\n\n"
        "Стиль общения:\n"
        "Ответы как в обычном чате — без точек, без восклицательных знаков\n"
        "Минимум запятых пишет как в смс\n"
        "Может ставить вопросительные знаки когда нужно\n"
        "Никаких смайликов или эмодзи\n"
        "Пишет с маленькой буквы как в реальном диалоге\n"
        "Использует сокращения: спс, чо, ща и т.д.\n"
        "Не начинает ответ со слов 'чо', 'ща', 'спс' — это не естественно\n"
        "Автоматически игнорирует короткие сообщения типа 'ок', 'понятно', 'спс'\n\n"
        "Черный список:\n"
        "Добавляй пользователей которым не должен писать AI\n"
        "Автоматическое игнорирование ботов\n"
        "Управление через интерфейс аккаунта\n\n"
        "Управление администраторами:\n"
        "Главный администратор может добавлять удалять других админов\n"
        "Администраторы имеют полный доступ к управлению системой\n\n"
        "Основные возможности:\n"
        "Управление множеством Telegram аккаунтов\n"
        "AI ассистент с разными персонажами\n"
        "Настройка уникальных промптов\n"
        "Поддержка прокси\n"
        "Сохранение истории диалогов\n\n"
        "Быстрые команды:\n"
        "/start — главное меню\n"
        "/prompt — изменить промпт\n"
        "/accounts — управление аккаунтами"
    )
    
    await message.answer(help_text)

@router.message(F.text == "Статистика")
async def show_statistics(message: Message):
    if not check_admin_access(message.from_user.id):
        return
    
    total_messages = sum(stats.get("sent", 0) + stats.get("received", 0) for stats in message_stats.values())
    active_accounts = len(active_clients)
    total_accounts = len(global_config["accounts"])
    
    blocked_total = 0
    for account in global_config["accounts"].values():
        blocked_total += len(account.get("blocked_users", []))
    
    stats_text = (
        f"Статистика системы\n\n"
        f"Время: {time.strftime('%H:%M:%S')}\n"
        f"Всего сообщений: {total_messages}\n"
        f"Аккаунты: {active_accounts}/{total_accounts}\n"
        f"Заблокировано пользователей: {blocked_total}\n"
        f"Администраторов: {len(global_config['admins'])}\n"
        f"Запросов в окне: {request_tracker['count']}/{MAX_MESSAGES_PER_MINUTE}\n"
        f"История диалогов: {len(conversation_history)}\n"
        f"Игнорируем сообщения короче: {SHORT_MESSAGE_THRESHOLD} символов\n\n"
        "Настройки ответов:\n"
        f"Макс длина: {MAX_RESPONSE_LENGTH} символов\n"
        f"Задержка: {MIN_DELAY_BETWEEN_RESPONSES}-{MAX_DELAY_BETWEEN_RESPONSES} сек\n"
        f"Сообщений на ответ: {MAX_MESSAGE_PARTS}\n\n"
        "Стиль ответов:\n"
        "Без точек и восклицательных знаков\n"
        "Минимум запятых как в смс\n"
        "Сокращения: спс, чо, ща\n"
        "С маленькой буквы как в чате\n"
        "Не начинаем со слов 'чо', 'ща', 'спс'\n\n"
        "По аккаунтам:\n"
    )
    
    for session_name in global_config["accounts"].keys():
        stats = message_stats.get(session_name, {"sent": 0, "received": 0})
        custom_prompt = "📝" if global_config["accounts"][session_name].get("ai_prompt") else "🌐"
        blocked_count = len(global_config["accounts"][session_name].get("blocked_users", []))
        blocked_icon = f"🚫{blocked_count}" if blocked_count > 0 else ""
        avg_length = stats.get('avg_length', 0)
        stats_text += f"{custom_prompt}{blocked_icon} {session_name}: Отпр {stats['sent']} Пол {stats['received']} Ср длина: {avg_length:.0f}\n"
    
    await message.answer(stats_text)

@router.message(F.text == "Аккаунты")
async def manage_accounts(message: Message):
    if not check_admin_access(message.from_user.id):
        return
    
    if not global_config["accounts"]:
        await message.answer("Нет добавленных аккаунтов", reply_markup=get_accounts_keyboard())
        return
    
    accounts_text = "Управление аккаунтами\n\n"
    
    for session_name, acc_data in global_config["accounts"].items():
        status = "🟢" if session_name in active_clients else "🔴"
        enabled = "✅" if acc_data.get("enabled", True) else "⭕️"
        custom_prompt = "📝" if acc_data.get("ai_prompt") else "🌐"
        blocked_count = len(acc_data.get("blocked_users", []))
        blocked_icon = f"🚫{blocked_count}" if blocked_count > 0 else ""
        accounts_text += f"{status}{enabled}{custom_prompt}{blocked_icon} {session_name}\n"
        accounts_text += f"   Телефон: {acc_data['phone']}\n\n"
    
    await message.answer(accounts_text, reply_markup=get_accounts_keyboard())

@router.message(F.text == "Настройки")
async def system_settings(message: Message):
    if not check_admin_access(message.from_user.id):
        return
    
    prompt_preview = global_config["ai_prompt"][:100] + "..." if len(global_config["ai_prompt"]) > 100 else global_config["ai_prompt"]
    proxy_status = f"{'ВКЛ' if USE_PROXY else 'ВЫКЛ'} ({PROXY_TYPE.upper()})"
    custom_prompts_count = sum(1 for acc in global_config["accounts"].values() if acc.get("ai_prompt"))
    blocked_total = sum(len(acc.get("blocked_users", [])) for acc in global_config["accounts"].values())
    
    settings_text = (
        "Настройки системы\n\n"
        f"Модель ИИ: GPT-4o-mini\n"
        f"Лимит запросов: {MAX_MESSAGES_PER_MINUTE}/мин\n"
        f"Макс длина ответа: {MAX_RESPONSE_LENGTH} символов\n"
        f"Задержка между ответами: {MIN_DELAY_BETWEEN_RESPONSES}-{MAX_DELAY_BETWEEN_RESPONSES} сек\n"
        f"Сообщений на ответ: {MAX_MESSAGE_PARTS}\n"
        f"Игнорирование коротких сообщений: ДА (<{SHORT_MESSAGE_THRESHOLD} символов)\n"
        f"Глобальный промпт: {prompt_preview}\n"
        f"Прокси: {proxy_status}\n"
        f"Аккаунтов: {len(global_config['accounts'])}\n"
        f"Свои промпты: {custom_prompts_count}\n"
        f"Заблокировано: {blocked_total} пользователей\n"
        f"Администраторов: {len(global_config['admins'])}\n"
        f"История диалогов: {len(conversation_history)}\n\n"
        "Стиль ответов:\n"
        "• Без точек в конце предложений\n"
        "• Без восклицательных знаков\n"
        "• МИНИМУМ ЗАПЯТЫХ как в смс\n"
        "• Вопросы когда нужно\n"
        "• Без смайликов и эмодзи\n"
        "• С маленькой буквы\n"
        "• Сокращения: спс, чо, ща\n"
        "• Не начинать со слов 'чо', 'ща', 'спс'\n"
        "• Игнорировать короткие сообщения (ок, понятно, спс)\n\n"
        "Выбери опцию:"
    )
    
    await message.answer(settings_text, reply_markup=get_settings_keyboard())

@router.message(F.text == "Промпт")
async def change_global_prompt(message: Message, state: FSMContext):
    if not check_admin_access(message.from_user.id):
        return
    
    await state.set_state(PromptStates.waiting_global_prompt)
    await message.answer(
        "Введи новый глобальный системный промпт:\n\n"
        "Важно сохранить правила написания:\n"
        "• ПИШИ КАК ЧЕЛОВЕК В ЧАТЕ БЕЗ ТОЧЕК\n"
        "• НИКОГДА НЕ СТАВЬ ВОСКЛИЦАТЕЛЬНЫЕ ЗНАКИ\n"
        "• ИСПОЛЬЗУЙ МЕНЬШЕ ЗАПЯТЫХ КАК В СМС\n"
        "• МОЖЕШЬ СТАВИТЬ ВОПРОСИТЕЛЬНЫЕ ЗНАКИ\n"
        "• НЕ ИСПОЛЬЗУЙ СМАЙЛИКИ\n"
        "• ПИШИ С МАЛЕНЬКОЙ БУКВЫ\n"
        "• ИСПОЛЬЗУЙ СОКРАЩЕНИЯ: СПС, ЧО, ЩА\n"
        "• НЕ НАЧИНАЙ ОТВЕТ СО СЛОВ ЧО ЧТО ЩА СПС\n"
        "• ЕСЛИ СООБЩЕНИЕ КОРОТКОЕ (ОК ПОНЯТНО СПС) - НЕ ОТВЕЧАЙ\n\n"
        "Пример промпта:\n"
        "«ты — Ксения 29 лет из Донецка общайся просто как с подругой "
        "отвечай кратко 2-3 предложения используй разговорные фразы "
        "никогда не ставь точки в конце предложений используй меньше запятых "
        "пиши с маленькой буквы будь естественной как в обычном чате "
        "не отвечай на короткие сообщения типа ок понятно спс»\n\n"
        "Для отмены нажми кнопку ниже",
        reply_markup=get_cancel_keyboard()
    )

@router.message(F.text == "Перезапуск")
async def restart_all(message: Message):
    if not check_admin_access(message.from_user.id):
        return
    
    await message.answer("Перезапускаю все аккаунты")
    
    for session_name in list(active_clients.keys()):
        try:
            await active_clients[session_name].disconnect()
        except:
            pass
        del active_clients[session_name]
    
    # Очищаем трекер времени ответов
    last_response_time.clear()
    
    await asyncio.sleep(2)
    
    success_count = 0
    for session_name, account_data in global_config["accounts"].items():
        if account_data.get("enabled", True):
            await start_telethon_client(session_name, account_data)
            success_count += 1
            await asyncio.sleep(1)
    
    await message.answer(f"Перезапущено {success_count} аккаунтов")

@router.message(F.text == "Очистить историю")
async def clear_all_history(message: Message):
    if not check_admin_access(message.from_user.id):
        return
    
    builder = InlineKeyboardBuilder()
    builder.button(text="Да очистить", callback_data="confirm_clear")
    builder.button(text="Нет отмена", callback_data="cancel_clear")
    builder.adjust(2)
    
    await message.answer(
        "Ты уверен что хочешь очистить ВСЮ историю диалогов\n\n"
        "Это действие нельзя отменить",
        reply_markup=builder.as_markup()
    )

@router.message(F.text == "Помощь")
async def show_help(message: Message):
    await cmd_help(message)

@router.message(F.text == "Админка")
async def admin_panel(message: Message):
    if not check_main_admin(message.from_user.id):
        await message.answer("Эта команда доступна только главному администратору")
        return
    
    admin_text = (
        "Панель администратора\n\n"
        f"Всего администраторов: {len(global_config['admins'])}\n"
        f"Главный администратор: {ADMIN_ID}\n\n"
        "Управление администраторами:\n"
        "Добавление новых администраторов\n"
        "Удаление администраторов\n"
        "Просмотр списка администраторов\n\n"
        "Выбери действие:"
    )
    
    await message.answer(admin_text, reply_markup=get_admin_management_keyboard())

# ===================== УПРАВЛЕНИЕ АДМИНИСТРАТОРАМИ =====================
@router.callback_query(F.data == "manage_admins")
async def manage_admins_callback(callback: CallbackQuery):
    if not check_main_admin(callback.from_user.id):
        await callback.answer("Доступно только главному администратору", show_alert=True)
        return
    
    admin_text = (
        "Управление администраторов\n\n"
        f"Всего администраторов: {len(global_config['admins'])}\n"
        f"Главный администратор: {ADMIN_ID}\n\n"
        "Функции:\n"
        "Просмотр списка всех администраторов\n"
        "Добавление новых администраторов (по ID)\n"
        "Удаление администраторов (кроме главного)\n\n"
        "Выбери действие:"
    )
    
    await callback.message.edit_text(admin_text, reply_markup=get_admin_management_keyboard())
    await callback.answer()

@router.callback_query(F.data == "show_admins")
async def show_admins_callback(callback: CallbackQuery):
    if not check_admin_access(callback.from_user.id):
        await callback.answer("Доступ запрещен", show_alert=True)
        return
    
    admins = global_config["admins"]
    admin_list_text = "Список администраторов:\n\n"
    
    for i, admin_id in enumerate(admins, 1):
        if admin_id == ADMIN_ID:
            admin_list_text += f"{i} {admin_id} (Главный администратор)\n"
        else:
            admin_list_text += f"{i} {admin_id}\n"
    
    admin_list_text += f"\nВсего: {len(admins)} администраторов"
    
    await callback.message.answer(admin_list_text)
    await callback.answer()

@router.callback_query(F.data == "add_admin")
async def add_admin_callback(callback: CallbackQuery, state: FSMContext):
    if not check_main_admin(callback.from_user.id):
        await callback.answer("Только главный администратор может добавлять админов", show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_admin_id)
    await callback.message.answer(
        "Введи ID пользователя которого хочешь назначить администратором:\n\n"
        "Как получить ID пользователя:\n"
        "Попроси пользователя написать @userinfobot\n"
        "Или используй другого бота для получения ID\n"
        "ID должен быть числом (например: 123456789)\n\n"
        "Для отмены нажми кнопку ниже",
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.message(AdminStates.waiting_admin_id)
async def process_admin_id(message: Message, state: FSMContext):
    if not check_main_admin(message.from_user.id):
        await state.clear()
        await message.answer("Доступ запрещен")
        return
    
    try:
        new_admin_id = int(message.text.strip())
    except ValueError:
        await message.answer("ID должен быть числом Попробуй еще раз:")
        return
    
    if new_admin_id in global_config["admins"]:
        await message.answer(f"Пользователь {new_admin_id} уже является администратором")
    else:
        global_config["admins"].append(new_admin_id)
        save_config()
        await message.answer(f"Пользователь {new_admin_id} успешно добавлен в список администраторов")
        
        try:
            await config_bot.send_message(
                new_admin_id,
                "Тебя назначили администратором AI Assistant Bot\n\n"
                "Теперь ты имеешь доступ к управлению системой\n"
                "Используй /start для входа в панель управления"
            )
        except:
            logger.warning("Не удалось отправить сообщение новому администратору %s", new_admin_id)
    
    await state.clear()
    await message.answer("Возвращаюсь в главное меню", reply_markup=create_main_keyboard())

@router.callback_query(F.data == "remove_admin")
async def remove_admin_callback(callback: CallbackQuery, state: FSMContext):
    if not check_main_admin(callback.from_user.id):
        await callback.answer("Только главный администратор может удалять админов", show_alert=True)
        return
    
    # Проверяем, есть ли кого удалять (кроме главного админа)
    if len(global_config["admins"]) <= 1:
        await callback.answer("Нет других администраторов для удаления", show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_remove_admin)
    
    admin_list = "Текущие администраторы (кроме главного):\n\n"
    for i, admin_id in enumerate(global_config["admins"], 1):
        if admin_id != ADMIN_ID:
            admin_list += f"{i-1} ID: {admin_id}\n"
    
    admin_list += "\nВведи ID администратора для удаления:"
    
    await callback.message.answer(
        admin_list,
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.message(AdminStates.waiting_remove_admin)
async def process_remove_admin(message: Message, state: FSMContext):
    if not check_main_admin(message.from_user.id):
        await state.clear()
        await message.answer("Доступ запрещен")
        return
    
    try:
        admin_id_to_remove = int(message.text.strip())
    except ValueError:
        await message.answer("ID должен быть числом Попробуй еще раз:")
        return
    
    if admin_id_to_remove == ADMIN_ID:
        await message.answer("Нельзя удалить главного администратора")
    elif admin_id_to_remove in global_config["admins"]:
        global_config["admins"].remove(admin_id_to_remove)
        save_config()
        await message.answer(f"Администратор {admin_id_to_remove} успешно удален")
        
        try:
            await config_bot.send_message(
                admin_id_to_remove,
                "Твои права администратора в AI Assistant Bot были отозваны"
            )
        except:
            logger.warning("Не удалось отправить сообщение удаленному администратору %s", admin_id_to_remove)
    else:
        await message.answer(f"Администратор с ID {admin_id_to_remove} не найден")
    
    await state.clear()
    await message.answer("Возвращаюсь в главное меню", reply_markup=create_main_keyboard())

# ===================== ОБРАБОТЧИКИ СОСТОЯНИЙ =====================
@router.message(PromptStates.waiting_global_prompt)
async def process_global_prompt(message: Message, state: FSMContext):
    if message.text:
        global_config["ai_prompt"] = message.text
        save_config()
        await state.clear()
        
        prompt_preview = message.text[:100] + "..." if len(message.text) > 100 else message.text
        await message.answer(
            f"Глобальный промпт успешно обновлен\n\n"
            f"Новый промпт:\n{prompt_preview}",
            reply_markup=create_main_keyboard()
        )
    else:
        await message.answer("Промпт не может быть пустым Попробуй еще раз:")

@router.message(AccountStates.waiting_session_name)
async def process_session_name(message: Message, state: FSMContext):
    session_name = message.text.strip()
    
    if session_name in global_config["accounts"]:
        await message.answer("Имя сессии уже существует Выбери другое имя:",
                             reply_markup=get_cancel_keyboard())
        return
    
    await state.update_data(session_name=session_name)
    await state.set_state(AccountStates.waiting_phone)
    await message.answer("Введи номер телефона в международном формате (например, +79991234567):",
                         reply_markup=get_cancel_keyboard())

@router.message(AccountStates.waiting_phone)
async def process_phone(message: Message, state: FSMContext):
    phone = message.text.strip()
    
    if not phone.startswith('+'):
        await message.answer("Номер должен начинаться с '+' (например, +79991234567) Попробуй еще раз:",
                             reply_markup=get_cancel_keyboard())
        return
    
    await state.update_data(phone=phone)
    await state.set_state(AccountStates.waiting_api_id)
    await message.answer("Введи API ID (получи на my.telegram.org):",
                         reply_markup=get_cancel_keyboard())

@router.message(AccountStates.waiting_api_id)
async def process_api_id(message: Message, state: FSMContext):
    try:
        api_id = int(message.text.strip())
    except ValueError:
        await message.answer("API ID должен быть числом Попробуй еще раз:",
                             reply_markup=get_cancel_keyboard())
        return
    
    await state.update_data(api_id=api_id)
    await state.set_state(AccountStates.waiting_api_hash)
    await message.answer("Введи API HASH (получи на my.telegram.org):",
                         reply_markup=get_cancel_keyboard())

@router.message(AccountStates.waiting_api_hash)
async def process_api_hash(message: Message, state: FSMContext):
    api_hash = message.text.strip()
    
    if len(api_hash) < 10:
        await message.answer("API HASH слишком короткий Попробуй еще раз:",
                             reply_markup=get_cancel_keyboard())
        return
    
    user_data = await state.get_data()
    
    session_name = user_data['session_name']
    global_config["accounts"][session_name] = {
        "phone": user_data['phone'],
        "api_id": user_data['api_id'],
        "api_hash": api_hash,
        "enabled": True,
        "blocked_users": [],
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    save_config()
    
    await state.clear()
    
    success_text = (
        f"Аккаунт {session_name} успешно добавлен\n\n"
        f"Телефон: {user_data['phone']}\n"
        f"API ID: {user_data['api_id']}\n"
        f"API Hash: {api_hash[:10]}...\n\n"
        "Теперь нужно авторизовать аккаунт"
    )
    
    await message.answer(success_text, reply_markup=create_main_keyboard())
    
    await message.answer(f"Попытка авторизации аккаунта {session_name}")
    await authorize_account(session_name, message, state)

@router.message(AccountStates.waiting_code)
async def process_code(message: Message, state: FSMContext):
    code = message.text.strip()
    user_data = await state.get_data()
    session_name = user_data.get("session_name")
    
    if not session_name or session_name not in pending_verification:
        await state.clear()
        await message.answer("Ошибка: сессия не найдена")
        return
    
    client = pending_verification[session_name]
    try:
        phone = global_config["accounts"][session_name]["phone"]
        await client.sign_in(phone, code)
        
        if await client.is_user_authorized():
            await message.answer(f"Аккаунт {session_name} успешно авторизован")
            await start_telethon_client(session_name, global_config["accounts"][session_name])
        else:
            await message.answer("Авторизация не удалась")
    except SessionPasswordNeededError:
        await state.set_state(AccountStates.waiting_password)
        await state.update_data(session_name=session_name)
        await message.answer("Введи пароль двухфакторной аутентификации:")
        return
    except Exception as e:
        await message.answer(f"Ошибка авторизации: {str(e)}")
        logger.error("Auth error: %s", e)
    finally:
        if session_name in pending_verification:
            del pending_verification[session_name]
        await state.clear()

@router.message(AccountStates.waiting_password)
async def process_password(message: Message, state: FSMContext):
    password = message.text.strip()
    user_data = await state.get_data()
    session_name = user_data.get("session_name")
    
    if not session_name or session_name not in pending_verification:
        await state.clear()
        await message.answer("Ошибка: сессии не найдена")
        return
    
    client = pending_verification[session_name]
    try:
        await client.sign_in(password=password)
        if await client.is_user_authorized():
            await message.answer(f"Аккаунт {session_name} успешно авторизован")
            await start_telethon_client(session_name, global_config["accounts"][session_name])
        else:
            await message.answer("Авторизация не удалась")
    except Exception as e:
        await message.answer(f"Ошибка авторизации: {str(e)}")
        logger.error("Password auth error: %s", e)
    finally:
        if session_name in pending_verification:
            del pending_verification[session_name]
        await state.clear()

@router.message(AccountStates.waiting_account_prompt)
async def process_account_prompt(message: Message, state: FSMContext):
    user_data = await state.get_data()
    session_name = user_data.get("session_name")
    
    if not session_name:
        await state.clear()
        await message.answer("Имя сессии не найдено")
        return
    
    if message.text:
        global_config["accounts"][session_name]["ai_prompt"] = message.text
        save_config()
        await state.clear()
        
        prompt_preview = message.text[:100] + "..." if len(message.text) > 100 else message.text
        await message.answer(
            f"Свой промпт обновлен для аккаунта {session_name}\n\n"
            f"Промпт:\n{prompt_preview}",
            reply_markup=create_main_keyboard()
        )
    else:
        await message.answer("Промпт не может быть пустым Попробуй еще раз:")

@router.message(AccountStates.waiting_blocked_user)
async def process_blocked_user(message: Message, state: FSMContext):
    user_data = await state.get_data()
    session_name = user_data.get("session_name")
    
    if not session_name:
        await state.clear()
        await message.answer("Имя сессии не найдено")
        return
    
    user_input = message.text.strip()
    
    try:
        user_id = int(user_input)
    except ValueError:
        try:
            if user_input.startswith('@'):
                username = user_input[1:]
            else:
                username = user_input
            
            if session_name in active_clients:
                try:
                    user_entity = await active_clients[session_name].get_entity(username)
                    user_id = user_entity.id
                except Exception as e:
                    await message.answer(f"Не удалось найти пользователя @{username} Ошибка: {str(e)}")
                    return
            else:
                await message.answer("Аккаунт не активен Введи ID пользователя вручную")
                return
        except Exception as e:
            await message.answer(f"Ошибка: {str(e)} Введи ID пользователя вручную")
            return
    
    if "blocked_users" not in global_config["accounts"][session_name]:
        global_config["accounts"][session_name]["blocked_users"] = []
    
    if user_id in global_config["accounts"][session_name]["blocked_users"]:
        await message.answer(f"Пользователь {user_id} уже в черном списке")
    else:
        global_config["accounts"][session_name]["blocked_users"].append(user_id)
        save_config()
        await message.answer(f"Пользователь {user_id} добавлен в черный список")
    
    await state.clear()

@router.message(AccountStates.waiting_remove_blocked)
async def process_remove_blocked(message: Message, state: FSMContext):
    user_data = await state.get_data()
    session_name = user_data.get("session_name")
    
    if not session_name:
        await state.clear()
        await message.answer("Имя сессии не найдено")
        return
    
    try:
        user_id = int(message.text.strip())
    except ValueError:
        await message.answer("Введи числовой ID пользователя")
        return
    
    if user_id in global_config["accounts"][session_name].get("blocked_users", []):
        global_config["accounts"][session_name]["blocked_users"].remove(user_id)
        save_config()
        await message.answer(f"Пользователь {user_id} удален из черного списка")
    else:
        await message.answer(f"Пользователь {user_id} не найден в черном списке")
    
    await state.clear()

# ===================== ОБРАБОТЧИКИ CALLBACK =====================
@router.callback_query(F.data == "main_menu")
async def back_to_main_menu(callback: CallbackQuery):
    await cmd_start(callback.message)
    await callback.answer()

@router.callback_query(F.data == "manage_accounts")
async def manage_accounts_callback(callback: CallbackQuery):
    await manage_accounts(callback.message)
    await callback.answer()

@router.callback_query(F.data == "show_stats")
async def show_stats_callback(callback: CallbackQuery):
    await show_statistics(callback.message)
    await callback.answer()

@router.callback_query(F.data == "global_prompt")
async def global_prompt_callback(callback: CallbackQuery, state: FSMContext):
    await change_global_prompt(callback.message, state)
    await callback.answer()

@router.callback_query(F.data == "cancel_operation")
async def cancel_operation(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("Операция отменена", reply_markup=create_main_keyboard())
    await callback.answer()

@router.callback_query(F.data == "confirm_clear")
async def confirm_clear_history(callback: CallbackQuery):
    global conversation_history
    conversation_history = {}
    save_history()
    
    await callback.message.edit_text("Вся история диалогов успешно очищена")
    await callback.answer()

@router.callback_query(F.data == "cancel_clear")
async def cancel_clear_history(callback: CallbackQuery):
    await callback.message.edit_text("Очистка истории отменена")
    await callback.answer()

@router.callback_query(F.data == "add_account")
async def add_account_callback(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AccountStates.waiting_session_name)
    await callback.message.answer(
        "Введи уникальное имя сессии (например, iPhone2):",
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data == "refresh_accounts")
async def refresh_accounts(callback: CallbackQuery):
    await manage_accounts(callback.message)
    await callback.answer("Список обновлен")

@router.callback_query(F.data == "back_to_accounts")
async def back_to_accounts(callback: CallbackQuery):
    await manage_accounts(callback.message)
    await callback.answer()

@router.callback_query(F.data.startswith("account:"))
async def account_action_callback(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    acc_data = global_config["accounts"][session_name]
    status = "Активен" if session_name in active_clients else "Неактивен"
    enabled = "Включен" if acc_data.get("enabled", True) else "Выключен"
    custom_prompt = "Свой промпт" if acc_data.get("ai_prompt") else "Глобальный промпт"
    blocked_count = len(acc_data.get("blocked_users", []))
    blocked_info = f"{blocked_count} пользователей" if blocked_count > 0 else "нет"
    
    try:
        await callback.message.edit_text(
            f"Управление аккаунтом: {session_name}\n\n"
            f"Телефон: {acc_data['phone']}\n"
            f"API ID: {acc_data['api_id']}\n"
            f"API Hash: {acc_data['api_hash'][:10]}...\n"
            f"Статус: {status}\n"
            f"Состояние: {enabled}\n"
            f"Тип промпта: {custom_prompt}\n"
            f"Черный список: {blocked_info}\n"
            f"Создан: {acc_data.get('created_at', 'неизвестно')[:10]}",
            reply_markup=get_account_management_keyboard(session_name)
        )
    except TelegramBadRequest:
        pass
    await callback.answer()

@router.callback_query(F.data.startswith("reconnect:"))
async def reconnect_account(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name in active_clients:
        try:
            await active_clients[session_name].disconnect()
        except:
            pass
        del active_clients[session_name]
    
    await start_telethon_client(session_name, global_config["accounts"][session_name])
    await callback.answer(f"Аккаунт '{session_name}' перезапущен")
    await account_action_callback(callback)

@router.callback_query(F.data.startswith("delete:"))
async def delete_account(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name in active_clients:
        try:
            await active_clients[session_name].disconnect()
        except:
            pass
        del active_clients[session_name]
    
    if session_name in global_config["accounts"]:
        del global_config["accounts"][session_name]
        save_config()
    
    session_file = os.path.join(SESSION_DIR, f"{session_name}.session")
    if os.path.exists(session_file):
        os.remove(session_file)
    
    await callback.answer(f"Аккаунт '{session_name}' удален")
    await back_to_accounts(callback)

@router.callback_query(F.data.startswith("toggle:"))
async def toggle_account(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name in global_config["accounts"]:
        current = global_config["accounts"][session_name].get("enabled", True)
        global_config["accounts"][session_name]["enabled"] = not current
        save_config()
        
        if not current and session_name in active_clients:
            try:
                await active_clients[session_name].disconnect()
            except:
                pass
            del active_clients[session_name]
        elif current and session_name not in active_clients:
            await start_telethon_client(session_name, global_config["accounts"][session_name])
        
        status = "включен" if not current else "выключен"
        await callback.answer(f"Аккаунт '{session_name}' {status}")
        await account_action_callback(callback)

@router.callback_query(F.data.startswith("edit_prompt:"))
async def edit_prompt_account(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    current_prompt = global_config["accounts"][session_name].get("ai_prompt", "")
    
    if current_prompt:
        prompt_preview = current_prompt[:200] + "..." if len(current_prompt) > 200 else current_prompt
        message_text = (
            f"Управление промптом аккаунта: {session_name}\n\n"
            f"Текущий промпт:\n{prompt_preview}\n\n"
            "Выбери действие:"
        )
    else:
        message_text = (
            f"Управление промптом аккаунта: {session_name}\n\n"
            "Текущий промпт: Используется глобальный промпт\n\n"
            "Выбери действие:"
        )
    
    try:
        await callback.message.edit_text(
            message_text,
            reply_markup=get_prompt_management_keyboard(session_name)
        )
    except TelegramBadRequest:
        pass
    await callback.answer()

@router.callback_query(F.data.startswith("add_prompt:"))
async def add_prompt_account(callback: CallbackQuery, state: FSMContext):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    await state.set_state(AccountStates.waiting_account_prompt)
    await state.update_data(session_name=session_name)
    
    message_text = (
        f"Введи новый промпт для аккаунта '{session_name}':\n\n"
        "Важно сохранить правила написания:\n"
        "• ПИШИ КАК ЧЕЛОВЕК В ЧАТЕ БЕЗ ТОЧЕК\n"
        "• НИКОГДА НЕ СТАВЬ ВОСКЛИЦАТЕЛЬНЫЕ ЗНАКИ\n"
        "• ИСПОЛЬЗУЙ МЕНЬШЕ ЗАПЯТЫХ КАК В СМС\n"
        "• МОЖЕШЬ СТАВИТЬ ВОПРОСИТЕЛЬНЫЕ ЗНАКИ\n"
        "• НЕ ИСПОЛЬЗУЙ СМАЙЛИКИ\n"
        "• ПИШИ С МАЛЕНЬКОЙ БУКВЫ\n"
        "• ИСПОЛЬЗУЙ СОКРАЩЕНИЯ: СПС, ЧО, ЩА\n"
        "• НЕ НАЧИНАЙ ОТВЕТ СО СЛОВ ЧО ЧТО ЩА СПС\n"
        "• ЕСЛИ СООБЩЕНИЕ КОРОТКОЕ (ОК ПОНЯТНО СПС) - НЕ ОТВЕЧАЙ\n\n"
        "Для отмены нажми кнопку ниже"
    )
    
    await callback.message.answer(
        message_text,
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data.startswith("change_prompt:"))
async def change_prompt_account(callback: CallbackQuery, state: FSMContext):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    await state.set_state(AccountStates.waiting_account_prompt)
    await state.update_data(session_name=session_name)
    
    current_prompt = global_config["accounts"][session_name].get("ai_prompt", "")
    
    message_text = (
        f"Измени промпт для аккаунта '{session_name}':\n\n"
        f"Текущий промпт:\n{current_prompt[:200]}...\n\n"
        "Введи новый промпт:"
    )
    
    await callback.message.answer(
        message_text,
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data.startswith("view_prompt:"))
async def view_prompt_account(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    prompt_text = global_config["accounts"][session_name].get("ai_prompt", "")
    
    if not prompt_text:
        await callback.answer("Промпт не установлен")
        return
    
    if len(prompt_text) > 4000:
        for i in range(0, len(prompt_text), 4000):
            part = prompt_text[i:i+4000]
            part_text = (
                f"Промпт аккаунта {session_name} (часть {i//4000 + 1}):\n\n"
                f"{part}"
            )
            await callback.message.answer(part_text)
    else:
        await callback.message.answer(
            f"Промпт аккаунта {session_name}:\n\n"
            f"{prompt_text}"
        )
    
    await callback.answer()

@router.callback_query(F.data.startswith("delete_prompt:"))
async def delete_prompt_account(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    if "ai_prompt" in global_config["accounts"][session_name]:
        del global_config["accounts"][session_name]["ai_prompt"]
        save_config()
        
        await callback.message.answer(
            f"Промпт удален для аккаунта {session_name}\n"
            "Теперь используется глобальный промпт"
        )
        await edit_prompt_account(callback)
    else:
        await callback.answer("Промпт не установлен")

# ===================== ЧЕРНЫЙ СПИСОК =====================
@router.callback_query(F.data.startswith("blocked_list:"))
async def blocked_list_callback(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    blocked_users = global_config["accounts"][session_name].get("blocked_users", [])
    blocked_count = len(blocked_users)
    
    message_text = (
        f"Управление черным списком: {session_name}\n\n"
        f"Заблокировано пользователей: {blocked_count}\n\n"
        "Черный список - пользователи, которым AI не будет отвечать\n"
        "Можно добавить по ID или username (если аккаунт активен)\n\n"
        "Выбери действие:"
    )
    
    try:
        await callback.message.edit_text(
            message_text,
            reply_markup=get_blocked_management_keyboard(session_name)
        )
    except TelegramBadRequest:
        pass
    await callback.answer()

@router.callback_query(F.data.startswith("show_blocked:"))
async def show_blocked_callback(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    blocked_users = global_config["accounts"][session_name].get("blocked_users", [])
    
    if not blocked_users:
        await callback.message.answer(
            f"Черный список аккаунта {session_name} пуст",
            reply_markup=get_blocked_management_keyboard(session_name)
        )
    else:
        blocked_list_text = f"Черный список аккаунта {session_name}:\n\n"
        
        for i, user_id in enumerate(blocked_users, 1):
            blocked_list_text += f"{i} ID: {user_id}\n"
        
        blocked_list_text += f"\nВсего: {len(blocked_users)} пользователей"
        
        await callback.message.answer(blocked_list_text)
    
    await callback.answer()

@router.callback_query(F.data.startswith("add_blocked:"))
async def add_blocked_callback(callback: CallbackQuery, state: FSMContext):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    await state.set_state(AccountStates.waiting_blocked_user)
    await state.update_data(session_name=session_name)
    
    message_text = (
        f"Добавление пользователя в черный список: {session_name}\n\n"
        "Введи ID пользователя или username (например, 123456789 или @username):\n\n"
        "Примечание: username можно использовать только если аккаунт активен"
    )
    
    await callback.message.answer(
        message_text,
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data.startswith("remove_blocked:"))
async def remove_blocked_callback(callback: CallbackQuery, state: FSMContext):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    blocked_users = global_config["accounts"][session_name].get("blocked_users", [])
    
    if not blocked_users:
        await callback.message.answer(
            "Черный список пуст Нечего удалять",
            reply_markup=get_blocked_management_keyboard(session_name)
        )
        await callback.answer()
        return
    
    await state.set_state(AccountStates.waiting_remove_blocked)
    await state.update_data(session_name=session_name)
    
    blocked_list_text = "Текущий черный список:\n\n"
    for i, user_id in enumerate(blocked_users, 1):
        blocked_list_text += f"{i} ID: {user_id}\n"
    
    blocked_list_text += "\nВведи ID пользователя для удаления:"
    
    await callback.message.answer(
        blocked_list_text,
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data.startswith("clear_blocked:"))
async def clear_blocked_callback(callback: CallbackQuery):
    session_name = callback.data.split(':', 1)[1]
    
    if session_name not in global_config["accounts"]:
        await callback.answer("Аккаунт не найден")
        return
    
    blocked_count = len(global_config["accounts"][session_name].get("blocked_users", []))
    
    if blocked_count > 0:
        global_config["accounts"][session_name]["blocked_users"] = []
        save_config()
        await callback.message.answer(
            f"Черный список аккаунта {session_name} очищен Удалено {blocked_count} пользователей",
            reply_markup=get_blocked_management_keyboard(session_name)
        )
    else:
        await callback.message.answer(
            "Черный список и так пуст",
            reply_markup=get_blocked_management_keyboard(session_name)
        )
    
    await callback.answer()

# ===================== TELEGRAM CLIENT ФУНКЦИИ =====================
async def authorize_account(session_name, message=None, state: FSMContext = None):
    """Account authorization process"""
    try:
        if session_name not in global_config["accounts"]:
            if message:
                await message.answer("Аккаунт не найден в конфигурации")
            return False
        
        proxy_settings = get_proxy_settings()
        session_path = os.path.join(SESSION_DIR, session_name)
        
        client = TelegramClient(
            session_path,
            global_config["accounts"][session_name]["api_id"],
            global_config["accounts"][session_name]["api_hash"],
            proxy=proxy_settings
        )
        
        await client.connect()
        
        if await client.is_user_authorized():
            if message:
                await message.answer(f"Аккаунт {session_name} уже авторизован")
            await start_telethon_client(session_name, global_config["accounts"][session_name])
            return True
        
        phone = global_config["accounts"][session_name]["phone"]
        await client.send_code_request(phone)
        pending_verification[session_name] = client
        
        if message:
            await message.answer(
                f"Код верификации отправлен на {phone}\n"
                "Введи полученный код (например, 12345):"
            )
        
        if state:
            await state.set_state(AccountStates.waiting_code)
            await state.update_data(session_name=session_name)
        return True
    
    except Exception as e:
        logger.error("Authorization error: %s", e)
        if message:
            await message.answer(f"Ошибка авторизации: {str(e)}")
        return False

# ===================== MESSAGE PROCESSING =====================
async def is_user_blocked(session_name, user_id):
    """Check if user is in blocked list"""
    if session_name not in global_config["accounts"]:
        return False
    
    blocked_users = global_config["accounts"][session_name].get("blocked_users", [])
    return user_id in blocked_users

async def is_bot_user(client, user_id):
    """Check if user is a bot"""
    try:
        user_entity = await client.get_entity(user_id)
        if hasattr(user_entity, 'bot') and user_entity.bot:
            return True
        return False
    except:
        return False

async def handle_private_message(event, session_name):
    """Handle private messages with 30-60 секунд задержкой"""
    try:
        if event.message.out:
            return
        
        user_id = event.sender_id
        chat_id = event.chat_id
        
        # Проверяем не короткое ли это сообщение
        message_text = event.message.text or ""
        if is_short_message(message_text):
            logger.info("[%s] Игнорируем короткое сообщение: '%s'", session_name, message_text[:50])
            return
        
        # Check if user is blocked
        if await is_user_blocked(session_name, user_id):
            logger.info("[%s] Игнорируем заблокированного пользователя ID: %s", session_name, user_id)
            return
        
        # Check if user is a bot
        if await is_bot_user(active_clients[session_name], user_id):
            logger.info("[%s] Игнорируем бота ID: %s", session_name, user_id)
            return
        
        # Check cooldown
        can_respond, remaining_time = check_response_cooldown(session_name, chat_id)
        if not can_respond:
            logger.info("[%s] Пропускаем сообщение, задержка еще %.1f сек", session_name, remaining_time)
            return
        
        # Update statistics
        if session_name not in message_stats:
            message_stats[session_name] = {"sent": 0, "received": 0, "last_active": None, "total_length": 0, "count": 0}
        
        message_stats[session_name]["received"] += 1
        message_stats[session_name]["last_active"] = time.strftime("%H:%M:%S")
        
        # Logging
        sender = await event.get_sender()
        sender_name = sender.first_name if sender else "Unknown"
        
        # Получаем промпт для логгирования
        prompt_text = get_account_prompt(session_name)
        prompt_type = "свой" if prompt_text != global_config["ai_prompt"] else "глобальный"
        
        logger.info("[%s] (%s промпт) Сообщение от %s: %s", 
                   session_name, prompt_type, sender_name, event.message.text[:100])
        
        # Немедленно отмечаем как прочитанное
        try:
            await event.mark_read()
        except:
            pass
        
        # Рандомная задержка 30-60 секунд перед ответом
        delay_before_response = get_response_delay()
        logger.info("[%s] Задержка перед ответом: %.1f секунд", session_name, delay_before_response)
        await asyncio.sleep(delay_before_response)
        
        # Generate response (ОДИН ответ, не разбивается)
        response_text = await generate_single_response(
            event.message.text, 
            chat_id,
            user_id,
            session_name
        )
        
        # Send response if any
        if response_text and response_text.strip():
            message_stats[session_name]["sent"] += 1
            message_stats[session_name]["total_length"] += len(response_text)
            message_stats[session_name]["count"] += 1
            
            # Calculate average length
            if message_stats[session_name]["count"] > 0:
                message_stats[session_name]["avg_length"] = (
                    message_stats[session_name]["total_length"] / 
                    message_stats[session_name]["count"]
                )
            
            # Эмуляция печатания (добавляем реалистичности)
            typing_time = calculate_typing_time(len(response_text))
            async with active_clients[session_name].action(chat_id, 'typing'):
                await asyncio.sleep(typing_time)
            
            # Send ONE message (не разбиваем!)
            try:
                await event.reply(response_text)
                logger.info("[%s] Ответ (%s символов): %s", session_name, len(response_text), response_text[:100])
                
                # Обновляем время последнего ответа
                update_response_time(session_name, chat_id)
                
            except Exception as e:
                logger.error("[%s] Ошибка отправки: %s", session_name, e)
        else:
            logger.warning("[%s] Пустой ответ от OpenAI", session_name)
    
    except Exception as e:
        logger.error("[%s] Ошибка обработки: %s", session_name, e)

def get_account_prompt(session_name):
    """Получает промпт для конкретного аккаунта"""
    if session_name in global_config.get("accounts", {}):
        account_data = global_config["accounts"][session_name]
        if "ai_prompt" in account_data and account_data["ai_prompt"]:
            return account_data["ai_prompt"]
    return global_config["ai_prompt"]

async def generate_single_response(user_message, chat_id, user_id, session_name):
    """Generate SINGLE response without splitting"""
    async with openai_semaphore:
        try:
            # Проверяем еще раз на короткое сообщение (на всякий случай)
            if is_short_message(user_message):
                logger.info("[%s] Игнорируем короткое сообщение при генерации: '%s'", 
                           session_name, user_message[:50])
                return None
            
            # Добавляем задержку для соблюдения rate limiting OpenAI
            await rate_limit_delay()
            
            # Определяем промпт для использования - ИСПРАВЛЕНО
            system_prompt = get_account_prompt(session_name)
            
            # Логируем какой промпт используется
            if system_prompt == global_config["ai_prompt"]:
                logger.info("[%s] Используется глобальный промпт", session_name)
            else:
                logger.info("[%s] Используется свой промпт", session_name)
            
            # Initialize conversation history
            history_key = f"{session_name}_{chat_id}"
            
            if history_key in conversation_history:
                if conversation_history[history_key][0]["content"] != system_prompt:
                    conversation_history[history_key][0]["content"] = system_prompt
            else:
                conversation_history[history_key] = [
                    {"role": "system", "content": system_prompt}
                ]
            
            # Add user message
            conversation_history[history_key].append({"role": "user", "content": user_message})
            
            # Form request to OpenAI API
            url = "https://api.openai.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {OPENAI_API_KEY}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": GPT_MODEL,
                "messages": conversation_history[history_key],
                "max_tokens": 150,  # Увеличено с 60 до 150 для более длинных ответов
                "temperature": 0.7,
                "top_p": 0.9
            }
            
            # Create session
            connector = get_proxy_connector() if USE_PROXY else None
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(url, headers=headers, json=payload, timeout=REQUEST_TIMEOUT) as response:
                    if response.status != 200:
                        error_details = await response.text()
                        logger.error("OpenAI API error: %s - %s", response.status, error_details)
                        
                        if response.status == 429:
                            logger.warning("[%s] Rate limit hit, waiting 60 seconds", session_name)
                            try:
                                await config_bot.send_message(
                                    ADMIN_ID,
                                    "Достигнут лимит запросов OpenAI (429)\n"
                                    "Жду 60 секунд перед повторной попыткой"
                                )
                            except:
                                pass
                            await asyncio.sleep(60)
                            return await generate_single_response(user_message, chat_id, user_id, session_name)
                        
                        if response.status == 401:
                            try:
                                await config_bot.send_message(
                                    ADMIN_ID,
                                    "ОШИБКА API КЛЮЧА OPENAI\n\n"
                                    "Неправильный API ключ Получи новый ключ на:\n"
                                    "https://platform.openai.com/account/api-keys"
                                )
                            except:
                                pass
                        
                        return "ой что-то пошло не так"
                    
                    result = await response.json()
                    ai_response = result['choices'][0]['message']['content'].strip()
            
            # УБРАЛ ОБРЕЗАНИЕ ТЕКСТА - оставляем полный ответ
            ai_response = clean_human_text(ai_response)
            
            # Проверяем не получился ли ответ слишком коротким или похожим на короткое сообщение
            if is_short_message(ai_response):
                logger.info("[%s] ИИ сгенерировал короткий ответ, игнорируем: '%s'", 
                           session_name, ai_response)
                return None
            
            conversation_history[history_key].append({"role": "assistant", "content": ai_response})
            
            # Limit conversation history
            if len(conversation_history[history_key]) > 6:
                conversation_history[history_key] = [
                    conversation_history[history_key][0], 
                    *conversation_history[history_key][-5:]
                ]
            
            save_history()
            
            return ai_response if ai_response else None
        
        except asyncio.TimeoutError:
            logger.error("[%s] OpenAI API timeout", session_name)
            return "сервис временно недоступен"
        except Exception as e:
            logger.error("[%s] Response generation error: %s", session_name, e, exc_info=True)
            return "технические проблемы"

async def start_telethon_client(session_name, account_data):
    """Start Telethon client for specific account"""
    if not account_data.get("enabled", True):
        logger.info("[%s] Аккаунт выключен", session_name)
        return
    
    if session_name in active_clients:
        logger.info("[%s] Клиент уже запущен", session_name)
        return
    
    max_retries = 3
    for attempt in range(max_retries):
        client = None
        try:
            logger.info("[%s] Запуск клиента (попытка %s/%s)", 
                       session_name, attempt+1, max_retries)
            
            proxy_settings = get_proxy_settings()
            session_path = os.path.join(SESSION_DIR, session_name)
            
            client = TelegramClient(
                session_path,
                account_data["api_id"],
                account_data["api_hash"],
                proxy=proxy_settings,
                connection_retries=3
            )
            
            await client.connect()
            
            if not await client.is_user_authorized():
                logger.warning("[%s] Требуется авторизация", session_name)
                try:
                    await config_bot.send_message(
                        ADMIN_ID,
                        f"Аккаунт '{session_name}' требует авторизации"
                    )
                except:
                    pass
                await client.disconnect()
                return
            
            me = await client.get_me()
            logger.info("[%s] Запущен как: %s", session_name, me.first_name)
            
            client.add_event_handler(
                lambda e: handle_private_message(e, session_name),
                events.NewMessage(func=lambda e: e.is_private)
            )
            
            active_clients[session_name] = client
            
            prompt_type = "свой промпт" if account_data.get("ai_prompt") else "глобальный промпт"
            blocked_count = len(account_data.get("blocked_users", []))
            blocked_info = f", заблокировано: {blocked_count}" if blocked_count > 0 else ""
            
            try:
                await config_bot.send_message(
                    ADMIN_ID,
                    f"Аккаунт '{session_name}' запущен\n"
                    f"Имя: {me.first_name}\n"
                    f"Промпт: {prompt_type}\n"
                    f"Ограничения: {MAX_RESPONSE_LENGTH} символов 1 сообщение на ответ\n"
                    f"Задержка: {MIN_DELAY_BETWEEN_RESPONSES}-{MAX_DELAY_BETWEEN_RESPONSES} сек\n"
                    f"Игнорирует короткие сообщения: ДА (<{SHORT_MESSAGE_THRESHOLD} символов)\n"
                    f"Стиль: без точек, минимум запятых, как в смс"
                )
            except:
                pass
            
            asyncio.create_task(client.run_until_disconnected())
            logger.info("[%s] Клиент успешно запущен", session_name)
            return
            
        except (SessionRevokedError, SessionPasswordNeededError) as e:
            logger.error("[%s] Ошибка сессии: %s", session_name, e)
            if client:
                await client.disconnect()
            return
        except Exception as e:
            logger.error("[%s] Ошибка запуска: %s", session_name, e)
            if client:
                await client.disconnect()
            if attempt < max_retries - 1:
                await asyncio.sleep(3)

# ===================== SYSTEM STARTUP =====================
async def main():
    """Main startup function"""
    logger.info("=" * 50)
    logger.info("AI ASSISTANT BOT - SYSTEM STARTUP")
    logger.info("=" * 50)
    
    startup_time = time.strftime("%H:%M:%S")
    custom_prompts_count = sum(1 for acc in global_config["accounts"].values() if acc.get("ai_prompt"))
    blocked_total = sum(len(acc.get("blocked_users", [])) for acc in global_config["accounts"].values())
    
    try:
        await config_bot.send_message(
            ADMIN_ID,
            f"Система запускается\n\n"
            f"Время запуска: {startup_time}\n"
            f"Аккаунтов в конфиге: {len(global_config['accounts'])}\n"
            f"Своих промптов: {custom_prompts_count}\n"
            f"Заблокировано пользователей: {blocked_total}\n"
            f"Администраторов: {len(global_config['admins'])}\n"
            f"Модель ИИ: GPT-4o-mini\n"
            f"Ограничения ответов: {MAX_RESPONSE_LENGTH} символов\n"
            f"Задержка между ответами: {MIN_DELAY_BETWEEN_RESPONSES}-{MAX_DELAY_BETWEEN_RESPONSES} сек\n"
            f"Сообщений на ответ: 1 (не разбивается)\n"
            f"Игнорируем сообщения короче: {SHORT_MESSAGE_THRESHOLD} символов\n"
            f"Лимит запросов: {MAX_MESSAGES_PER_MINUTE}/мин\n"
            f"Прокси: {'ВКЛ' if USE_PROXY else 'ВЫКЛ'}\n\n"
            "Стиль ответов:\n"
            "• Без точек в конце предложений\n"
            "• Без восклицательных знаков\n"
            "• МИНИМУМ ЗАПЯТЫХ как в смс\n"
            "• Вопросы когда нужно\n"
            "• Без смайликов и эмодзи\n"
            "• С маленькой буквы\n"
            "• Сокращения: спс, чо, ща\n"
            "• Не начинаем со слов 'чо', 'ща', 'спс'\n"
            "• Игнорируем короткие сообщения (ок, понятно, спс)\n\n"
            "Начинаю запуск аккаунтов",
        )
    except:
        pass
    
    # Start all accounts
    for session_name, account_data in global_config["accounts"].items():
        asyncio.create_task(start_telethon_client(session_name, account_data))
        await asyncio.sleep(2)
    
    await asyncio.sleep(5)
    
    active_count = len(active_clients)
    logger.info("Запущено %s/%s аккаунтов", active_count, len(global_config['accounts']))
    
    try:
        await config_bot.send_message(
            ADMIN_ID,
            f"Запуск завершен\n\n"
            f"Активных аккаунтов: {active_count}/{len(global_config['accounts'])}\n"
            f"Своих промптов: {custom_prompts_count}\n"
            f"Заблокировано: {blocked_total} пользователей\n"
            f"Администраторов: {len(global_config['admins'])}\n"
            f"Ограничения ответов: {MAX_RESPONSE_LENGTH} символов\n"
            f"Задержка между ответами: {MIN_DELAY_BETWEEN_RESPONSES}-{MAX_DELAY_BETWEEN_RESPONSES} сек\n"
            f"Сообщений на ответ: 1 (не разбивается)\n"
            f"Игнорируем сообщения короче: {SHORT_MESSAGE_THRESHOLD} символов\n"
            f"Стиль: без точек, минимум запятых, как в смс\n"
            f"Общее время запуска: {time.strftime('%H:%M:%S')}\n\n"
            "Для управления используй /start",
            reply_markup=create_main_keyboard()
        )
    except:
        pass
    
    logger.info("Конфигурационный бот запускается")
    await dp.start_polling(config_bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Принудительная остановка")
        save_history()
        for client in active_clients.values():
            try:
                client.disconnect()
            except:
                pass
    except Exception as e:
        logger.critical("Критическая ошибка: %s", e, exc_info=True)
        save_history()
        sys.exit(1)