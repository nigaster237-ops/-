# Clean Render Deployment

Upload this repository to GitHub, then on Render select:
Build Command: pip install -r requirements.txt
Start Command: python bot.py
